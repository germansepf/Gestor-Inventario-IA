def search_images_for_product(raw_title: str) -> str:
    """
    Esta función ya no buscará imágenes automáticamente.
    En su lugar, la columna de imágenes se dejará vacía para que el usuario las agregue manualmente.
    """
    return ""  # Devuelve una cadena vacía
